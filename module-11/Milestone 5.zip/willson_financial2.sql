CREATE TABLE Employee(
 EmployeeID INT PRIMARY KEY,
 FirstName VARCHAR(50),
 LastName VARCHAR(50),
 Role VARCHAR(50),
 Phone VARCHAR(20),
 Email VARCHAR(100),
 HireDate DATE
);
CREATE TABLE Client(
 ClientID INT PRIMARY KEY,
 FirstName VARCHAR(50),
 LastName VARCHAR(50),
 Phone VARCHAR(20),
 Email VARCHAR(100),
 Address VARCHAR(100),
 DateAdded DATE,
 EmployeeID INT,
 FOREIGN KEY (EmployeeID) REFERENCES Employee(EmployeeID)
);
CREATE TABLE Asset(
 AssetID INT PRIMARY KEY,
 AssetType VARCHAR(50),
 Value DECIMAL(12,2),
 PurchaseDate DATE,
 ClientID INT,
 FOREIGN KEY (ClientID) REFERENCES Client(ClientID)
);
CREATE TABLE TransactionRecord(
 TransactionID INT PRIMARY KEY,
 TransactionDate DATE,
 Amount DECIMAL(12,2),
 TransactionType VARCHAR(50),
 ClientID INT,
 AssetID INT,
 FOREIGN KEY (ClientID) REFERENCES Client(ClientID),
 FOREIGN KEY (AssetID) REFERENCES Asset(AssetID)
);
CREATE TABLE Appointment(
 AppointmentID INT PRIMARY KEY,
 AppointmentDate DATE,
 AppointmentTime TIME,
 Purpose VARCHAR(100),
 ClientID INT,
 EmployeeID INT,
 FOREIGN KEY (ClientID) REFERENCES Client(ClientID),
 FOREIGN KEY (EmployeeID) REFERENCES Employee(EmployeeID)
);
CREATE TABLE Billing(
 BillingID INT PRIMARY KEY,
 BillingDate DATE,
 Amount DECIMAL(12,2),
 Status VARCHAR(20),
 ClientID INT,
 FOREIGN KEY (ClientID) REFERENCES Client(ClientID)
);

INSERT INTO Employee VALUES
(1,'Jake','Willson','Financial Advisor','555-1001','john@wf.com','2023-01-15'),
(2,'Ned','Willson','Financial Advisor','555-1002','mary@wf.com','2022-08-20'),
(3,'Phoenix','Two Star','Office Administrator','555-1003','david@wf.com','2021-11-10'),
(4,'June','Santos','Compliance Manager','555-1004','sarah@wf.com','2020-05-05'),
(5,'James','Miller','Advisor','555-1005','james@wf.com','2023-03-18'),
(6,'Linda','Wilson','Advisor','555-1006','linda@wf.com','2024-02-01');

INSERT INTO Client VALUES
(1,'Alan','Cooper','555-2001','alan@mail.com','El Paso','2026-02-10',1),
(2,'Beth','White','555-2002','beth@mail.com','El Paso','2026-03-08',2),
(3,'Carl','Young','555-2003','carl@mail.com','El Paso','2026-04-15',3),
(4,'Dana','Hall','555-2004','dana@mail.com','El Paso','2026-05-05',1),
(5,'Evan','King','555-2005','evan@mail.com','El Paso','2026-06-12',2),
(6,'Faith','Scott','555-2006','faith@mail.com','El Paso','2026-07-03',3);

INSERT INTO Asset VALUES
(1,'Stocks',10000,'2025-01-15',1),
(2,'Bond',5000,'2025-02-10',2),
(3,'IRA',15000,'2024-11-20',3),
(4,'ETF',8000,'2025-03-05',4),
(5,'CD',4000,'2025-01-28',5),
(6,'Mutual Fund',12000,'2024-12-12',6);

INSERT INTO TransactionRecord VALUES
(1,'2026-07-01',150,'Deposit',1,1),
(2,'2026-07-02',200,'Withdrawal',1,1),
(3,'2026-07-03',250,'Deposit',1,1),
(4,'2026-07-04',300,'Withdrawal',1,1),
(5,'2026-07-05',350,'Deposit',1,1),
(6,'2026-07-06',400,'Withdrawal',1,1),
(7,'2026-07-07',450,'Deposit',1,1),
(8,'2026-07-08',500,'Withdrawal',1,1),
(9,'2026-07-09',550,'Deposit',1,1),
(10,'2026-07-10',600,'Withdrawal',1,1),
(11,'2026-07-11',650,'Deposit',1,1),
(12,'2026-07-12',700,'Withdrawal',1,1),
(13,'2026-07-01',150,'Deposit',3,3),
(14,'2026-07-02',200,'Withdrawal',3,3),
(15,'2026-07-03',250,'Deposit',3,3),
(16,'2026-07-04',300,'Withdrawal',3,3),
(17,'2026-07-05',350,'Deposit',3,3),
(18,'2026-07-06',400,'Withdrawal',3,3),
(19,'2026-07-07',450,'Deposit',3,3),
(20,'2026-07-08',500,'Withdrawal',3,3),
(21,'2026-07-09',550,'Deposit',3,3),
(22,'2026-07-10',600,'Withdrawal',3,3),
(23,'2026-07-11',650,'Deposit',3,3),
(24,'2026-07-12',700,'Withdrawal',3,3),
(25,'2026-07-13',750,'Deposit',3,3),
(26,'2026-07-14',800,'Withdrawal',3,3),
(27,'2026-07-01',150,'Deposit',2,2),
(28,'2026-07-02',200,'Withdrawal',2,2),
(29,'2026-07-03',250,'Deposit',2,2),
(30,'2026-06-01',150,'Deposit',4,4),
(31,'2026-06-02',200,'Withdrawal',4,4),
(32,'2026-06-03',250,'Deposit',4,4),
(33,'2026-06-04',300,'Withdrawal',4,4),
(34,'2026-06-05',350,'Deposit',4,4),
(35,'2026-07-01',150,'Deposit',5,5),
(36,'2026-07-02',200,'Withdrawal',5,5),
(37,'2026-07-01',150,'Deposit',6,6),
(38,'2026-07-02',200,'Withdrawal',6,6);

INSERT INTO Appointment VALUES
(1,'2026-03-01','09:00:00','Review',1,1),(2,'2026-03-02','10:00:00','Planning',2,2),
(3,'2026-03-03','11:00:00','Investment',3,3),(4,'2026-03-04','13:00:00','Review',4,1),
(5,'2026-03-05','14:00:00','Planning',5,2),(6,'2026-03-06','15:00:00','Review',6,3);

INSERT INTO Billing VALUES
(1,'2026-04-01',150.00,'Paid',1),
(2,'2026-04-01',150.00,'Pending',2),
(3,'2026-04-01',150.00,'Paid',3),
(4,'2026-04-01',150.00,'Pending',4),
(5,'2026-04-01',150.00,'Paid',5),
(6,'2026-04-01',150.00,'Pending',6);