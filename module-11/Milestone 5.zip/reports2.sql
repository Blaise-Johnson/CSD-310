-- Willson Financial - Case Study Report Queries
-- Group Bravo, CSD 310
--
-- Four reports: Client Growth, Average Client Asset Value,
-- Billing Status, and High-Transaction Clients.
--
-- Table names are PascalCase to match the build script (willson_financial.sql):
-- Client, Asset, Billing, TransactionRecord. Column names are case-insensitive.
-- Report order matches groupb-willson-reports.py.


-- ============================================================
-- Report 1: Client Growth
-- How many clients were added in each of the past six months?
--
-- The window is anchored to the most recent DateAdded in the data so it
-- returns rows regardless of when it is run. Signups are spread one per
-- month across Feb-Jul 2026.
-- Expected result: six rows, 2026-02 through 2026-07, NewClients 1 each.
-- ============================================================

SELECT
    DATE_FORMAT(DateAdded, '%Y-%m') AS SignupMonth,
    COUNT(ClientID)                 AS NewClients
FROM Client
WHERE DateAdded >= DATE_SUB(
        (SELECT MAX(DateAdded) FROM Client), INTERVAL 6 MONTH)
GROUP BY SignupMonth
ORDER BY SignupMonth;

-- Today-relative alternative. Anchoring to MAX(DateAdded) above is used
-- instead so the report never returns empty if the data ages past the
-- six-month window.
-- SELECT
--     DATE_FORMAT(DateAdded, '%Y-%m') AS SignupMonth,
--     COUNT(ClientID)                 AS NewClients
-- FROM Client
-- WHERE DateAdded >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
-- GROUP BY SignupMonth
-- ORDER BY SignupMonth;


-- ============================================================
-- Report 2: Average Client Asset Value
-- Average amount of assets (in currency) for the entire client list.
-- Expected average on the current data: 9000.00
-- ============================================================

-- Per-client asset totals, highest first (shown for context).
SELECT
    c.ClientID,
    CONCAT(c.FirstName,' ',c.LastName) AS Client,
    COALESCE(SUM(a.Value), 0)          AS TotalAssetValue
FROM Client c
LEFT JOIN Asset a
    ON a.ClientID = c.ClientID
GROUP BY c.ClientID, c.FirstName, c.LastName
ORDER BY TotalAssetValue DESC;

-- Average of those totals across the entire client list.
SELECT ROUND(AVG(ClientAssetTotal), 2) AS AvgAssetsPerClient
FROM (
    SELECT c.ClientID, COALESCE(SUM(a.Value), 0) AS ClientAssetTotal
    FROM Client c
    LEFT JOIN Asset a ON a.ClientID = c.ClientID
    GROUP BY c.ClientID
) AS per_client;


-- ============================================================
-- Report 3: Billing Status
-- Displays each client's billing information and payment status.
-- ============================================================

SELECT
    b.BillingID,
    CONCAT(c.FirstName,' ',c.LastName) AS Client,
    b.BillingDate,
    b.Amount,
    b.Status
FROM Billing b
JOIN Client c
    ON b.ClientID = c.ClientID
ORDER BY b.Status, b.BillingDate;


-- ============================================================
-- Report 4: High-Transaction Clients
-- Which clients have more than 10 transactions in a single month?
-- Expected result: Carl Young 2026-07 (14), Alan Cooper 2026-07 (12).
-- ============================================================

SELECT
    c.ClientID,
    CONCAT(c.FirstName,' ',c.LastName)     AS Client,
    DATE_FORMAT(t.TransactionDate,'%Y-%m') AS TxnMonth,
    COUNT(*)                               AS Transactions
FROM TransactionRecord t
JOIN Client c
    ON c.ClientID = t.ClientID
GROUP BY c.ClientID, TxnMonth
HAVING COUNT(*) > 10
ORDER BY Transactions DESC;