# Group B
    #Justin Bradley
    #Natalia Carbajal
    #Blaise Johnson
    #Luis Rodriguez
# Professor Sue Sampson
# CSD 310 - Assignment 11.2 Milestone 5

import mysql.connector
from mysql.connector import errorcode
from dotenv import dotenv_values
# using our .env file
secrets = dotenv_values(".env")
""" database config object """

config = {
    "user": secrets["USER"],
    "password": secrets["PASSWORD"],
    "host": secrets["HOST"],
    "port": int(secrets["PORT"]),
    "database": secrets["DATABASE"],
    "raise_on_warnings": True
}
""" MySQL: mysql_test.py Connection test code """
""" try/catch block for handling potential MySQL database errors """
db = None
try:
# connect to the database using the config object
    db = mysql.connector.connect(**config)
# ---------------- Report 1 ----------------
    cursor = db.cursor(dictionary=True)

    print("\n========== CLIENT GROWTH REPORT ==========\n")

    # New clients added per month over the last six months.
    # Window is anchored to the most recent DateAdded in the data so it
    # returns rows regardless of when it runs. If the seed data is ever
    # updated to recent signup dates, switch the WHERE line to:
    #   WHERE DateAdded >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
    cursor.execute("""
    SELECT
        DATE_FORMAT(DateAdded, '%Y-%m') AS SignupMonth,
        COUNT(ClientID)                 AS NewClients
    FROM Client
    WHERE DateAdded >= DATE_SUB(
            (SELECT MAX(DateAdded) FROM Client), INTERVAL 6 MONTH)
    GROUP BY SignupMonth
    ORDER BY SignupMonth;
    """)

    report = cursor.fetchall()

    for row in report:
        print(f"Month: {row['SignupMonth']}")
        print(f"New Clients: {row['NewClients']}")
        print()
# ---------------- Report 2 ----------------
    cursor = db.cursor(dictionary=True)

    print("\n========== AVERAGE CLIENT ASSET VALUE ==========\n")

    # Per-client asset totals, highest first.
    cursor.execute("""
    SELECT
        c.ClientID,
        CONCAT(c.FirstName,' ',c.LastName) AS Client,
        COALESCE(SUM(a.Value), 0)          AS TotalAssetValue
    FROM Client c
    LEFT JOIN Asset a
        ON a.ClientID = c.ClientID
    GROUP BY c.ClientID, c.FirstName, c.LastName
    ORDER BY TotalAssetValue DESC;
    """)

    report = cursor.fetchall()

    for row in report:
        print(f"Client: {row['Client']}")
        print(f"Total Assets: ${row['TotalAssetValue']}")
        print()

    # Average of those totals across the entire client list.
    cursor.execute("""
    SELECT ROUND(AVG(ClientAssetTotal), 2) AS AvgAssetsPerClient
    FROM (
        SELECT c.ClientID, COALESCE(SUM(a.Value), 0) AS ClientAssetTotal
        FROM Client c
        LEFT JOIN Asset a ON a.ClientID = c.ClientID
        GROUP BY c.ClientID
    ) AS per_client;
    """)

    summary = cursor.fetchone()
    print(f"Average Assets Per Client: ${summary['AvgAssetsPerClient']}")
    print()
    # ---------------- Report 3 ----------------
    cursor = db.cursor(dictionary=True)

    print("\n========== BILLING STATUS REPORT ==========\n")

    cursor.execute("""
    SELECT
        b.BillingID,
        CONCAT(c.FirstName,' ',c.LastName) AS Client,
        b.BillingDate,
        b.Amount,
        b.Status
    FROM Billing b
    JOIN Client c
        ON b.ClientID = c.ClientID
    ORDER BY b.Status, b.BillingDate;
    """)

    report = cursor.fetchall()

    for row in report:
        print(f"Billing ID: {row['BillingID']}")
        print(f"Client: {row['Client']}")
        print(f"Billing Date: {row['BillingDate']}")
        print(f"Amount: ${row['Amount']}")
        print(f"Status: {row['Status']}")
        print()
    # ---------------- Report 4 ----------------
    cursor = db.cursor(dictionary=True)

    print("\n========== HIGH-TRANSACTION CLIENTS ==========\n")

    # Clients with more than 10 transactions in a single month.
    cursor.execute("""
    SELECT
        c.ClientID,
        CONCAT(c.FirstName,' ',c.LastName)     AS Client,
        DATE_FORMAT(t.TransactionDate,'%Y-%m') AS TxnMonth,
        COUNT(*)                               AS Transactions
    FROM TransactionRecord t
    JOIN Client c
        ON c.ClientID = t.ClientID
    GROUP BY c.ClientID, TxnMonth
    HAVING COUNT(*) > 10
    ORDER BY Transactions DESC;
    """)

    report = cursor.fetchall()

    for row in report:
        print(f"Client: {row['Client']}")
        print(f"Month: {row['TxnMonth']}")
        print(f"Transactions: {row['Transactions']}")
        print()

    # Connection status
    print("\nDatabase user {} connected to MySQL on host {} with database {}"
          .format(config["user"], config["host"], config["database"]))

    input("\n\nPress Enter to continue.")

except mysql.connector.Error as err:
    if err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
        print("The supplied username or password are invalid")
    elif err.errno == errorcode.ER_BAD_DB_ERROR:
        print("The specified database does not exist")
    else:
        print(err)

finally:
    if db is not None:
        db.close()